// COURSE: CSCI1620
// TERM: FALL 2020
// 
// NAME:
// RESOURCES:

package snake;

public class Item
{

}
