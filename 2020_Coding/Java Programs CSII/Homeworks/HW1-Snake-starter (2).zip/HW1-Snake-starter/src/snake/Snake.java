// COURSE: CSCI1620
// TERM: FALL 2020
// 
// NAME:
// RESOURCES:

package src.snake;

public class Snake
{

}
