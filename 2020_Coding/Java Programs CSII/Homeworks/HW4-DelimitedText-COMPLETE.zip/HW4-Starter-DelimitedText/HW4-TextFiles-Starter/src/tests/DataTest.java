// COURSE: CSCI1620
// TERM: FALL 2020
//
// NAME: Maverick Berkland and Abdoul Latoundji
// RESOURCES: Classmate assistance was used in the creation of this java program.package tests;
package tests;

import static org.junit.Assert.*;
import org.junit.Test;

import analytics.Data;

public class DataTest
{
	Integer[] intArrayClosed =
	{
			32, 39510, 63546, 59948, 63833, 57542, 62106, 554, 60846, 33, 92737, 22894, 61077, 83092, 13558, 18019,
			89799, 50517, 85140, 56498, 64870, 41611, 80062, 72428, 45409, 84838, 1712, 96022, 87702, 30360, 47376,
			49682, 45297, 43508, 5731, 84006, 24947, 49826, 58076, 65835, 13294, 95739, 97648, 46067, 37196, 6663,
			97381, 44600, 92944, 94225, 50633, 44605, 33364, 82468, 31294, 2276, 53905, 29381, 46387, 40268, 72605,
			28140, 79662, 49123, 55951, 5343, 95173, 21168, 27614, 37165, 2892, 99810
	};
	Integer[] intArrayClosed2 =
	{
			99810, 23436, 63546, 59948, 63833, 57542, 62106, 554, 60846, 33, 92737, 22894, 61077, 83092, 13558, 18019,
			89799, 50517, 85140, 56498, 64870, 41611, 80062, 72428, 45409, 84838, 1712, 96022, 87702, 30360, 47376,
			49682, 45297, 43508, 5731, 84006, 24947, 49826, 58076, 65835, 13294, 95739, 97648, 46067, 37196, 6663,
			97381, 44600, 92944, 94225, 50633, 44605, 33364, 82468, 31294, 2276, 53905, 29381, 46387, 40268, 72605,
			28140, 79662, 49123, 55951, 5343, 95173, 21168, 27614, 37165, 2892, 32
	};
	Integer[] intArrayClosed3 =
	{
			23436, 63546, 59948, 63833, 57542, 62106, 554, 60846, 99810, 33, 92737, 22894, 61077, 83092, 13558, 18019,
			89799, 50517, 85140, 56498, 64870, 41611, 80062, 72428, 45409, 84838, 1712, 96022, 87702, 30360, 47376,
			49682, 45297, 43508, 5731, 84006, 24947, 49826, 58076, 65835, 13294, 95739, 97648, 46067, 37196, 6663,
			97381, 44600, 92944, 94225, 50633, 44605, 33364, 82468, 31294, 2276, 53905, 29381, 46387, 40268, 72605,
			28140, 79662, 49123, 55951, 5343, 95173, 21168, 27614, 37165, 2892, 39510
	};
	Integer[] intArrayOpen =
	{
			1492, 11465, 93920, 16803, 77476, 72168, 10746, 1711, 97310, 53971, 28013, 59707, 56431, 24568, 2686, 4135,
			89126, 46899, 2668, 24403, 40727, 20801, 20638, 69980, 96194, 50172, 66107, 77380, 43352, 96536, 49208,
			77052, 28377, 26136, 41227, 34514, 35186, 67854, 91103, 23830, 7525, 77614, 6753, 84618, 12902, 63437,
			31510, 95526, 87520, 35099, 11439, 21286, 69305, 33594, 1813, 31921, 73659, 3354, 89407, 20645, 10320, 3059,
			78658, 2276, 49190, 66974, 44680, 20149, 5970, 2704, 55833, 97412, null, null, null, null, null, null, null,
			null, null, null, null, null
	};
	Integer[] intArrayOpen2 =
	{
			97412, 6456, 11465, 93920, 16803, 77476, 72168, 10746, 1711, 97310, 53971, 28013, 59707, 56431, 24568, 2686, 4135,
			89126, 46899, 2668, 24403, 40727, 20801, 20638, 69980, 96194, 50172, 66107, 77380, 43352, 96536, 49208,
			77052, 26136, 41227, 34514, 35186, 67854, 91103, 23830, 7525, 77614, 6753, 84618, 12902, 63437,
			31510, 95526, 87520, 35099, 11439, 21286, 69305, 33594, 1813, 31921, 73659, 3354, 89407, 20645, 10320, 3059,
			78658, 2276, 49190, 66974, 44680, 20149, 5970, 2704, 55833, 1492, null, null, null, null, null, null, null,
			null, null, null, null, null
	};
	Integer[] intArrayOpen3 =
	{
			6456, 11465, 93920, 16803, 77476, 72168, 10746, 1492, 97412, 53971, 28013, 59707, 56431, 24568, 2686, 4135,
			89126, 46899, 2668, 24403, 40727, 20801, 20638, 69980, 96194, 50172, 66107, 77380, 43352, 96536, 49208,
			77052, 97310, 26136, 41227, 34514, 35186, 67854, 91103, 23830, 7525, 77614, 6753, 84618, 12902, 63437,
			31510, 95526, 87520, 35099, 11439, 21286, 69305, 33594, 1711, 31921, 73659, 3354, 89407, 20645, 10320, 3059,
			78658, 2276, 49190, 66974, 44680, 20149, 5970, 2704, 55833, 1813, null, null, null, null, null, null, null,
			null, null, null, null, null
	};
	Integer[] intArrayNoisy =
	{

			36633, 11465, 93920, 16803, 77476, 72168, 10746, 1492, 10320, 53971, 28013, 59707, 56431, 24568, 2686, 4135,
			89126, 46899, 2668, 24403, 40727, 20801, 20638, 69980, 12902, 50172, 66107, 77380, 43352, 96536, 49208,
			77052, 26136, 41227, 34514, null, null, null, null, null, null, null, null, null, null, null, null, 97310,
			35186, 67854, 91103, 23830, 7525, 77614, 6753, 84618, 96194, 63437, 31510, 95526, 87520, 35099, 11439,
			21286, 69305, 33594, 1813, 31921, 73659, 3354, 1312, 20645, 97412, 3059, 78658, 2276, 49190, 66974, 44680,
			20149, 5970, 2704, 55833, 28377
	};
	Double[] doubleArrayClosed =
	{
			435.53330, 3195.97082, 1151.04632, 2110.48148, 1878.23058, 2356.53918, 8107.61214, 799.96556, 2819.09055,
			1057.89793, 4095.60471, 3542.96726, 2090.47072, 1974.81423, 8809.39533, 2426.21751, 5952.15313, 66.64332,
			317.18297, 3114.79920, 6555.47077, 52.67701, 4471.17267, 18.99591, 6602.19111, 283.69606, 1291.02986,
			6361.87627, 1263.20028, 1907.80129, 483.91351, 2055.96265, 545.07166, 3436.71792, 318.92681, 358.25504,
			3617.23625, 317.10210, 2060.74699, 332.98567, 903.01777, 9526.12674, 4200.84734, 137.66940, 3172.85067,
			5446.71998, 4562.91990, 5583.48328, 1737.86818, 4133.04740, 1508.43400, 587.08481, 5975.92916, 1049.74100,
			3951.99951, 896.39323, 1247.78444, 881.43636, 325.28162, 2864.30876, 1544.52824, 830.69831, 2281.74254,
			379.76235, 635.47871, 1298.97210, 6684.69640, 361.70435, 4310.00162, 1170.36592, 461.89446, 2254.17374
	};
	Double[] doubleArrayClosed2 =
	{
			18.99591, 3195.97082, 1151.04632, 2110.48148, 1878.23058, 2356.53918, 8107.61214, 799.96556, 2819.09055,
			1057.89793, 4095.60471, 3542.96726, 2090.47072, 1974.81423, 8309.39533, 2426.21751, 5952.15313, 66.64332,
			317.18297, 3114.79920, 6555.47077, 52.67701, 4471.17267, 435.53330, 6602.19111, 283.69606, 1291.02986,
			6361.87627, 1263.20028, 1907.80129, 483.91351, 2055.96265, 545.07166, 3436.71792, 318.92681, 358.25504,
			3617.23625, 387.10210, 2060.74699, 332.98567, 903.01777, 2254.17374, 4200.84734, 137.66940, 3172.85067,
			5446.71998, 4562.91990, 5583.48328, 1737.86818, 4133.04740, 1508.46401, 587.08481, 5975.92916, 1049.74100,
			3951.99951, 896.39323, 1247.78444, 881.43636, 325.28162, 2864.30876, 1544.52824, 830.69831, 2281.74254,
			379.76235, 635.47871, 1298.97210, 6684.69640, 361.70435, 4310.00162, 1170.36592, 461.89446, 9526.12674
	};
	Double[] doubleArrayClosed3 =
	{
			9526.12674, 3195.97082, 1151.04632, 2110.48148, 1878.23058, 2356.53918, 8107.61214, 799.96556, 2819.09055,
			1057.89793, 4095.60471, 3542.96726, 2090.47072, 1974.81423, 8809.39533, 2426.21751, 5952.15313, 66.64332,
			317.18297, 3114.79920, 6555.47077, 52.67701, 4371.17267, 2254.17474, 6602.19151, 283.69606, 1291.02986,
			6361.87627, 1263.20028, 1907.80129, 453.91351, 2055.96265, 545.07166, 3436.71792, 318.92681, 358.25504,
			3617.23625, 317.10210, 2060.74699, 332.98567, 903.01777, 435.53330, 4200.84734, 137.66940, 3172.85067,
			5446.71998, 4562.91990, 5583.48328, 1737.86818, 4133.04740, 1508.43400, 587.08467, 5975.92916, 1049.74100,
			3951.99951, 896.39323, 1247.78444, 881.43636, 325.28162, 2864.30876, 1544.52824, 830.69831, 2281.74254,
			379.76235, 635.47871, 1298.97210, 6684.69640, 361.70435, 4310.00162, 1170.36592, 461.89446, 18.99591
	};
	Double[] doubleArrayOpen =
	{
			8371.44435, 2725.97456, 85.14465, 8856.79926, 2448.89278, 7552.22590, 1962.12483, 4569.14973, 2121.58250,
			1032.98489, 2402.46455, 3865.04936, 2136.93495, 1451.11924, 120.02866, 393.61685, 2352.97019, 550.31461,
			713.68699, 6476.61658, 2726.38977, 3310.52241, 2957.00705, 3710.28853, 4267.26597, 2051.03147, 3124.54145,
			288.31042, 570.63106, 2308.43483, 6058.07966, 2471.66160, 1492.57054, 7311.97675, 2560.42733, 1999.34944,
			634.30390, 1586.36964, 199.85178, 11.90203, 1680.79571, 2366.69239, 794.00709, 3298.50033, 3124.34305,
			2080.95635, 5556.01060, 666.85760, 1359.37635, 3652.49187, 3898.30632, 3302.13586, 4449.74589, 869.04517,
			978.19132, 609.41058, 3312.77121, 383.52709, 364.05128, 1887.10994, 1819.81810, 2144.04648, 2021.54983,
			2709.11173, 8245.49331, 66.55959, 2793.63210, 134.23004, 8600.59421, 6637.05219, 687.63068, 4851.54013,
			null, null, null, null, null, null, null, null
	};
	Double[] doubleArrayOpen2 =
	{
			11.90203, 8371.44435, 2725.97456, 85.14465, 2448.89278, 7552.22590, 1962.12483, 4569.14973, 2121.58250,
			1032.98489, 2402.46455, 3865.04936, 2136.93495, 1451.11924, 120.02566, 393.61685, 2352.97019, 550.31461,
			713.68699, 6476.61658, 2726.38977, 1310.52241, 2957.00705, 1710.28853, 4267.26597, 2051.03147, 3124.54145,
			288.31042, 570.63106, 2308.43483, 6058.07966, 2471.66160, 1492.57054, 7311.97675, 2560.42733, 1999.34944,
			634.30390, 1586.36964, 199.85178, 8856.79926, 1680.79571, 2366.69239, 794.00709, 3298.50033, 3124.34305,
			2080.95635, 5556.01060, 666.85760, 1359.33645, 3652.49187, 3898.30632, 3302.13586, 4449.74589, 869.04517,
			978.19132, 609.41058, 3312.77121, 383.52709, 364.05128, 1887.10994, 1819.81810, 2144.04648, 2021.54983,
			2709.11173, 8245.49331, 66.55959, 2793.63210, 134.23004, 8600.59421, 6637.05219, 687.63068, 4851.54013,
			null, null, null, null, null, null, null, null
	};
	Double[] doubleArrayOpen3 =
	{
			11.90203, 8371.44435, 2725.97456, 85.14465, 2448.89278, 7552.22590, 1962.12483, 4569.14973, 2121.58250,
			1032.98489, 2402.46455, 3865.04936, 2136.93495, 1451.11924, 120.02566, 393.61685, 2352.97019, 550.31461,
			713.68699, 6476.61658, 2726.38977, 3310.52241, 2957.00705, 1710.28853, 4267.26597, 2051.03147, 3124.54145,
			288.31042, 570.63106, 2308.43483, 6058.07966, 2471.66160, 3992.57054, 7311.97675, 2560.42733, 1999.34944,
			634.30390, 1586.36964, 199.85178, 8856.79926, 1680.79571, 2366.69239, 794.00709, 3298.50033, 3124.34305,
			2080.95635, 5556.01060, 666.85760, 1359.33645, 3652.49187, 3898.30632, 3302.13586, 4449.74589, 869.04517,
			978.19132, 609.41058, 3312.77121, 383.52709, 364.05128, 1887.10994, 1819.81810, 2144.04648, 2021.54983,
			2709.11173, 8245.49331, 66.55959, 2793.63210, 134.23004, 8600.59421, 6637.05219, 687.63068, 4851.54013,
			null, null, null, null, null, null, null, null
	};
	Double[] doubleArrayNoisy =
	{

			8371.44435, 2725.97456, 85.14465, 2448.89278, 7552.22590, 1962.12483, 4569.14973, 2121.58250,
			1032.98489, 2402.46455, 3865.04936, 2136.93495, 1451.11924, 120.02566, 393.61685, 2352.97019, 550.31461,
			713.68699, 6476.61658, 2726.38977, 3310.52241, 2957.00705, 1710.28853, 4267.26597, 2051.03147, 3124.54145,
			288.31042, null, null, null, null, null, null, null, null, 570.63106, 2308.43483, 6058.07966, 2471.66160,
			1492.57054, 7311.97675, 2560.42733, 1999.34944, 634.30390, 1586.36964, 199.85178, 11.90203, 1680.79571,
			2366.69239, 794.00709, 3298.50033, 3124.34305, 2080.95635, 5556.01060, 666.85760, 1359.33645, 3652.49187,
			3898.30632, 3302.13586, 4449.74589, 869.04517, 978.19132, 609.41058, 3312.77121, 383.52709, 364.05128,
			1887.10994, 1819.81810, 2144.04648, 2021.54983, 2709.11173, 8245.49331, 66.55959, 2793.63210, 134.23004,
			8600.59421, 6637.05219, 687.63068, 4851.54013, 8856.79926
	};

	@Test
	public void minimumTest()
	{
		// length 0 test
		assertNull(Data.minimum(new Integer[0]));
		assertNull(Data.minimum(new Double[0]));

		// nonzero starts with null
		assertNull(Data.minimum(new Integer[]
		{
				null, 0
		}));
		assertNull(Data.minimum(new Double[]
		{
				null, 0d
		}));

		// filled array tests
		assertEquals(32, (int) Data.minimum(intArrayClosed));
		assertEquals(32, (int) Data.minimum(intArrayClosed2));
		assertEquals(33, (int) Data.minimum(intArrayClosed3));
		assertEquals(18.99591d, (double) Data.minimum(doubleArrayClosed), 0.00001d);
		assertEquals(18.99591d, (double) Data.minimum(doubleArrayClosed2), 0.00001d);
		assertEquals(18.99591d, (double) Data.minimum(doubleArrayClosed3), 0.00001d);

		// null extended test
		assertEquals(1492, (int) Data.minimum(intArrayOpen));
		assertEquals(1492, (int) Data.minimum(intArrayOpen2));
		assertEquals(1492, (int) Data.minimum(intArrayOpen3));
		assertEquals(11.90203d, (double) Data.minimum(doubleArrayOpen), 0.00001d);
		assertEquals(11.90203d, (double) Data.minimum(doubleArrayOpen2), 0.00001d);
		assertEquals(11.90203d, (double) Data.minimum(doubleArrayOpen3), 0.00001d);

		// null extended with data after test
		assertEquals(1492, (int) Data.minimum(intArrayNoisy));
		assertEquals(85.14465d, (double) Data.minimum(doubleArrayNoisy), 0.00001d);
	}
	@Test
	public void maximumTest()
	{
		// length 0 test
		assertNull(Data.maximum(new Integer[0]));
		assertNull(Data.maximum(new Double[0]));

		// nonzero starts with null
		assertNull(Data.maximum(new Integer[]
		{
				null, 0
		}));
		assertNull(Data.maximum(new Double[]
		{
				null, 0d
		}));

		// filled array tests
		assertEquals(99810, (int) Data.maximum(intArrayClosed));
		assertEquals(99810, (int) Data.maximum(intArrayClosed2));
		assertEquals(99810, (int) Data.maximum(intArrayClosed3));
		assertEquals(9526.12674d, (double) Data.maximum(doubleArrayClosed), 0.00001);
		assertEquals(9526.12674d, (double) Data.maximum(doubleArrayClosed2), 0.00001);
		assertEquals(9526.12674d, (double) Data.maximum(doubleArrayClosed3), 0.00001);

		// null extended test
		assertEquals(97412, (int) Data.maximum(intArrayOpen));
		assertEquals(97412, (int) Data.maximum(intArrayOpen2));
		assertEquals(97412, (int) Data.maximum(intArrayOpen3));
		assertEquals(8856.79926d, (double) Data.maximum(doubleArrayOpen), 0.00001);
		assertEquals(8856.79926d, (double) Data.maximum(doubleArrayOpen2), 0.00001);
		assertEquals(8856.79926d, (double) Data.maximum(doubleArrayOpen3), 0.00001);

		// null extended with data after test
		assertEquals(96536, (int) Data.maximum(intArrayNoisy));
		assertEquals(8371.44435d, (double) Data.maximum(doubleArrayNoisy), 0.00001);
	}
	@Test
	public void averageTest()
	{
		assertTrue(Data.average(new Integer[0]).isNaN());
		assertTrue(Data.average(new Double[0]).isNaN());

		// nonzero starts with null
		assertTrue(Data.average(new Integer[]
		{
				null, 0
		}).isNaN());
		assertTrue(Data.average(new Double[]
		{
				null, 0d
		}).isNaN());

		// filled array tests
		assertEquals(51049.48611d, Data.average(intArrayClosed), 0.00001);
		assertEquals(50826.23611d, Data.average(intArrayClosed2), 0.00001);
		assertEquals(51374.54167d, Data.average(intArrayClosed3), 0.00001);
		assertEquals(2493.67512d, Data.average(doubleArrayClosed), 0.00001);
		assertEquals(2487.70331d, Data.average(doubleArrayClosed2), 0.00001);
		assertEquals(2491.86958d, Data.average(doubleArrayClosed3), 0.00001);

		// null extended test
		assertEquals(43447.55556d, Data.average(intArrayOpen), 0.00001);
		assertEquals(43143.09722d, Data.average(intArrayOpen2), 0.00001);
		assertEquals(43143.09722d, Data.average(intArrayOpen3), 0.00001);
		assertEquals(2710.77258d, Data.average(doubleArrayOpen), 0.00001);
		assertEquals(2655.21642d, Data.average(doubleArrayOpen2), 0.00001);
		assertEquals(2717.71642d, Data.average(doubleArrayOpen3), 0.00001);

		// null extended with data after test
		assertEquals(41438.91429d, Data.average(intArrayNoisy), 0.00001);
		assertEquals(2658.06223d, Data.average(doubleArrayNoisy), 0.00001);
	}
	@Test
	public void standardDeviationTest()
	{
		assertTrue(Data.standardDeviation(new Integer[0]).isNaN());
		assertTrue(Data.standardDeviation(new Double[0]).isNaN());

		// nonzero starts with null
		assertTrue(Data.standardDeviation(new Integer[]
		{
				null, 0
		}).isNaN());
		assertTrue(Data.standardDeviation(new Double[]
		{
				null, 0d
		}).isNaN());

		// filled array tests
		assertEquals(29128.68469d, Data.standardDeviation(intArrayClosed), 0.00001);
		assertEquals(29277.48849d, Data.standardDeviation(intArrayClosed2), 0.00001);
		assertEquals(28684.75512d, Data.standardDeviation(intArrayClosed3), 0.00001);
		assertEquals(2284.58176d, Data.standardDeviation(doubleArrayClosed), 0.00001);
		assertEquals(2265.14173d, Data.standardDeviation(doubleArrayClosed2), 0.00001);
		assertEquals(2283.77840d, Data.standardDeviation(doubleArrayClosed3), 0.00001);

		// null extended test
		assertEquals(31242.22909d, Data.standardDeviation(intArrayOpen), 0.00001);
		assertEquals(31493.41086d, Data.standardDeviation(intArrayOpen2), 0.00001);
		assertEquals(31493.41086d, Data.standardDeviation(intArrayOpen3), 0.00001);
		assertEquals(2258.95379d, Data.standardDeviation(doubleArrayOpen), 0.00001);
		assertEquals(2263.19475d, Data.standardDeviation(doubleArrayOpen2), 0.00001);
		assertEquals(2259.43817d, Data.standardDeviation(doubleArrayOpen3), 0.00001);

		// null extended with data after test
		assertEquals(27937.5416d, Data.standardDeviation(intArrayNoisy), 0.00001);
		assertEquals(2092.80857d, Data.standardDeviation(doubleArrayNoisy), 0.00001);
	}
	@Test
	public void inaneTest()
	{
		assertNotNull(new Data());
	}
}
