package PlagueIncSimulator;
/**
 * Write a description of interface Disease here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Disease
{
    public int randomness(int rand);
    public void printer();
    public void Done();
}
